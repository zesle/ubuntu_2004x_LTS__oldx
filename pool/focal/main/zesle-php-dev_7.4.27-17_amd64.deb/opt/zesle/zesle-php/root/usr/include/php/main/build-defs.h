/*
   +----------------------------------------------------------------------+
   | PHP Version 7                                                        |
   +----------------------------------------------------------------------+
   | Copyright (c) The PHP Group                                          |
   +----------------------------------------------------------------------+
   | This source file is subject to version 3.01 of the PHP license,      |
   | that is bundled with this package in the file LICENSE, and is        |
   | available through the world-wide-web at the following url:           |
   | http://www.php.net/license/3_01.txt                                  |
   | If you did not receive a copy of the PHP license and are unable to   |
   | obtain it through the world-wide-web, please send a note to          |
   | license@php.net so we can mail you a copy immediately.               |
   +----------------------------------------------------------------------+
   | Author: Stig Sæther Bakken <ssb@php.net>                             |
   +----------------------------------------------------------------------+
*/

#define CONFIGURE_COMMAND " '../configure'  '--prefix=/usr' '--includedir=${prefix}/include' '--mandir=${prefix}/share/man' '--infodir=${prefix}/share/info' '--sysconfdir=/etc' '--localstatedir=/var' '--disable-silent-rules' '--libdir=${prefix}/lib/x86_64-linux-gnu' '--libexecdir=${prefix}/lib/x86_64-linux-gnu' '--runstatedir=/run' '--disable-maintainer-mode' '--build=x86_64-linux-gnu' '--host=x86_64-linux-gnu' '--config-cache' '--cache-file=../config.cache' '--program-prefix=' '--disable-dependency-tracking' '--prefix=/opt/zesle/zesle-php/root/usr' '--exec-prefix=/opt/zesle/zesle-php/root/usr' '--bindir=/opt/zesle/zesle-php/root/usr/bin' '--sbindir=/opt/zesle/zesle-php/root/usr/sbin' '--sysconfdir=/opt/zesle/zesle-php/root/etc' '--datadir=/opt/zesle/zesle-php/root/usr/share' '--includedir=/opt/zesle/zesle-php/root/usr/include' '--libdir=/opt/zesle/zesle-php/root/usr/lib64' '--libexecdir=/opt/zesle/zesle-php/root/usr/libexec' '--localstatedir=/opt/zesle/zesle-php/root/var' '--sharedstatedir=/opt/zesle/zesle-php/root/var/lib' '--mandir=/opt/zesle/zesle-php/root/usr/share/man' '--infodir=/opt/zesle/zesle-php/root/usr/share/info' '--with-libdir=lib' '--with-config-file-path=/opt/zesle/zesle-php/root/etc' '--with-config-file-scan-dir=/opt/zesle/zesle-php/root/etc/php.d' '--disable-debug' '--with-password-argon2=/usr' '--with-pic' '--without-pear' '--with-freetype' '--with-xpm' '--without-gdbm' '--with-jpeg' '--with-openssl' '--with-pcre-regex=/usr' '--with-zlib' '--with-layout=GNU' '--with-kerberos' '--with-libxml' '--with-system-tzdata' '--with-mhash' '--enable-fpm' '--with-fpm-systemd' '--libdir=/opt/zesle/zesle-php/root/usr/lib64/php' '--enable-pcntl' '--enable-opcache' '--with-imap=/usr' '--with-imap-ssl' '--enable-mbstring' '--with-webp' '--enable-gd' '--with-gmp' '--enable-calendar' '--enable-bcmath' '--with-bz2' '--enable-ctype' '--enable-exif' '--enable-ftp' '--with-gettext' '--with-iconv' '--enable-sockets' '--enable-tokenizer' '--with-xmlrpc' '--with-ldap' '--with-ldap-sasl' '--enable-mysqlnd' '--with-mysqli=mysqlnd' '--with-mysql-sock=/var/run/mysqld/mysqld.sock' '--enable-dom' '--enable-simplexml' '--enable-xml' '--with-snmp=/usr' '--enable-soap' '--with-xsl=/usr' '--enable-xmlreader' '--enable-xmlwriter' '--with-curl' '--enable-pdo' '--with-pdo-odbc=unixODBC,/usr' '--with-pdo-mysql=mysqlnd' '--with-pdo-sqlite=/usr' '--with-sqlite3=/usr' '--enable-json' '--with-zip' '--without-readline' '--with-libedit' '--with-pspell' '--enable-phar' '--with-tidy=/usr' '--enable-sysvmsg' '--enable-sysvshm' '--enable-sysvsem' '--enable-shmop' '--enable-posix' '--with-unixODBC=/usr' '--enable-intl' '--with-enchant=/usr' '--enable-fileinfo' '--enable-redis' '--enable-zesle' 'build_alias=x86_64-linux-gnu' 'host_alias=x86_64-linux-gnu'"
#define PHP_ODBC_CFLAGS	"-I/usr/include"
#define PHP_ODBC_LFLAGS		"-L/usr/lib"
#define PHP_ODBC_LIBS		"-lodbc"
#define PHP_ODBC_TYPE		"unixODBC"
#define PHP_OCI8_DIR			""
#define PHP_OCI8_ORACLE_VERSION		""
#define PHP_PROG_SENDMAIL	"/usr/sbin/sendmail"
#define PEAR_INSTALLDIR         ""
#define PHP_INCLUDE_PATH	".:"
#define PHP_EXTENSION_DIR       "/opt/zesle/zesle-php/root/usr/lib64/php/20190902"
#define PHP_PREFIX              "/opt/zesle/zesle-php/root/usr"
#define PHP_BINDIR              "/opt/zesle/zesle-php/root/usr/bin"
#define PHP_SBINDIR             "/opt/zesle/zesle-php/root/usr/sbin"
#define PHP_MANDIR              "/opt/zesle/zesle-php/root/usr/share/man"
#define PHP_LIBDIR              "/opt/zesle/zesle-php/root/usr/lib64/php"
#define PHP_DATADIR             "/opt/zesle/zesle-php/root/usr/share"
#define PHP_SYSCONFDIR          "/opt/zesle/zesle-php/root/etc"
#define PHP_LOCALSTATEDIR       "/opt/zesle/zesle-php/root/var"
#define PHP_CONFIG_FILE_PATH    "/opt/zesle/zesle-php/root/etc"
#define PHP_CONFIG_FILE_SCAN_DIR    "/opt/zesle/zesle-php/root/etc/php.d"
#define PHP_SHLIB_SUFFIX        "so"
#define PHP_SHLIB_EXT_PREFIX    ""
