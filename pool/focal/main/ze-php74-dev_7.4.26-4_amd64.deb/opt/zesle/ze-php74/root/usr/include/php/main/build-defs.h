/*
   +----------------------------------------------------------------------+
   | PHP Version 7                                                        |
   +----------------------------------------------------------------------+
   | Copyright (c) The PHP Group                                          |
   +----------------------------------------------------------------------+
   | This source file is subject to version 3.01 of the PHP license,      |
   | that is bundled with this package in the file LICENSE, and is        |
   | available through the world-wide-web at the following url:           |
   | http://www.php.net/license/3_01.txt                                  |
   | If you did not receive a copy of the PHP license and are unable to   |
   | obtain it through the world-wide-web, please send a note to          |
   | license@php.net so we can mail you a copy immediately.               |
   +----------------------------------------------------------------------+
   | Author: Stig Sæther Bakken <ssb@php.net>                             |
   +----------------------------------------------------------------------+
*/

#define CONFIGURE_COMMAND " '../configure'  '--prefix=/usr' '--includedir=${prefix}/include' '--mandir=${prefix}/share/man' '--infodir=${prefix}/share/info' '--sysconfdir=/etc' '--localstatedir=/var' '--disable-silent-rules' '--libdir=${prefix}/lib/x86_64-linux-gnu' '--libexecdir=${prefix}/lib/x86_64-linux-gnu' '--runstatedir=/run' '--disable-maintainer-mode' '--build=x86_64-linux-gnu' '--host=x86_64-linux-gnu' '--config-cache' '--cache-file=../config.cache' '--program-prefix=' '--disable-dependency-tracking' '--prefix=/opt/zesle/ze-php74/root/usr' '--exec-prefix=/opt/zesle/ze-php74/root/usr' '--bindir=/opt/zesle/ze-php74/root/usr/bin' '--sbindir=/opt/zesle/ze-php74/root/usr/sbin' '--sysconfdir=/opt/zesle/ze-php74/root/etc' '--datadir=/opt/zesle/ze-php74/root/usr/share' '--includedir=/opt/zesle/ze-php74/root/usr/include' '--libdir=/opt/zesle/ze-php74/root/usr/lib' '--libexecdir=/opt/zesle/ze-php74/root/usr/libexec' '--localstatedir=/opt/zesle/ze-php74/root/var' '--sharedstatedir=/opt/zesle/ze-php74/root/var/lib' '--mandir=/opt/zesle/ze-php74/root/usr/share/man' '--infodir=/opt/zesle/ze-php74/root/usr/share/info' '--with-libdir=lib' '--libdir=/opt/zesle/ze-php74/root/usr/lib/php' '--with-config-file-path=/opt/zesle/ze-php74/root/etc' '--with-config-file-scan-dir=/opt/zesle/ze-php74/root/etc/php.d' '--disable-debug' '--with-password-argon2=/usr' '--with-pic' '--without-pear' '--with-bz2' '--with-freetype' '--with-xpm' '--without-gdbm' '--with-gettext' '--with-iconv' '--with-jpeg' '--with-openssl' '--with-pcre-regex=/usr' '--with-zlib' '--with-layout=GNU' '--enable-exif' '--enable-ftp' '--enable-sockets' '--with-kerberos' '--enable-shmop' '--with-libxml-dir=/usr' '--with-system-tzdata' '--with-mhash' '--enable-embed' '--without-mysqli' '--disable-pdo' '--disable-gd' '--disable-dom' '--disable-dba' '--without-unixODBC' '--disable-opcache' '--disable-xmlreader' '--disable-xmlwriter' '--without-sqlite3' '--disable-phar' '--disable-fileinfo' '--disable-json' '--without-pspell' '--without-curl' '--disable-posix' '--disable-xml' '--disable-simplexml' '--disable-exif' '--without-gettext' '--without-iconv' '--disable-ftp' '--without-bz2' '--disable-ctype' '--disable-shmop' '--disable-sockets' '--disable-tokenizer' '--disable-sysvmsg' '--disable-sysvshm' '--disable-sysvsem' '--without-gmp' '--disable-calendar' 'build_alias=x86_64-linux-gnu' 'host_alias=x86_64-linux-gnu' 'CFLAGS=-g -O2 -fdebug-prefix-map=/root/rpmbuild/php-7.4.26=. -fstack-protector-strong -Wformat -Werror=format-security -O2 -Wall -pedantic -fsigned-char -fno-strict-aliasing -mshstk -g'"
#define PHP_ODBC_CFLAGS	""
#define PHP_ODBC_LFLAGS		""
#define PHP_ODBC_LIBS		""
#define PHP_ODBC_TYPE		""
#define PHP_OCI8_DIR			""
#define PHP_OCI8_ORACLE_VERSION		""
#define PHP_PROG_SENDMAIL	"/usr/sbin/sendmail"
#define PEAR_INSTALLDIR         ""
#define PHP_INCLUDE_PATH	".:"
#define PHP_EXTENSION_DIR       "/opt/zesle/ze-php74/root/usr/lib/php/20190902"
#define PHP_PREFIX              "/opt/zesle/ze-php74/root/usr"
#define PHP_BINDIR              "/opt/zesle/ze-php74/root/usr/bin"
#define PHP_SBINDIR             "/opt/zesle/ze-php74/root/usr/sbin"
#define PHP_MANDIR              "/opt/zesle/ze-php74/root/usr/share/man"
#define PHP_LIBDIR              "/opt/zesle/ze-php74/root/usr/lib/php"
#define PHP_DATADIR             "/opt/zesle/ze-php74/root/usr/share"
#define PHP_SYSCONFDIR          "/opt/zesle/ze-php74/root/etc"
#define PHP_LOCALSTATEDIR       "/opt/zesle/ze-php74/root/var"
#define PHP_CONFIG_FILE_PATH    "/opt/zesle/ze-php74/root/etc"
#define PHP_CONFIG_FILE_SCAN_DIR    "/opt/zesle/ze-php74/root/etc/php.d"
#define PHP_SHLIB_SUFFIX        "so"
#define PHP_SHLIB_EXT_PREFIX    ""
